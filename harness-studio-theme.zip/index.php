<?php
/**
 * Main Template File for WordPress Theme
 *
 * @package HarnessStudio
 */

get_header(); ?>

<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo( 'charset' ); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php wp_title( '|', true, 'right' ); ?> The Truth About AI Automation | Founder Manifesto</title>
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

  <!-- Glow Background Spotlight -->
  <div class="glow-spotlight-top"></div>

  <!-- Top Live Notice Bar -->
  <div class="top-notice-bar">
    <div class="container-wide notice-flex">
      <div>
        <span class="live-badge"><span class="pulse"></span> DIRECT META WABA CLOUD API</span>
        <span id="live-ticker" style="margin-left: 0.75rem; font-family: var(--font-mono);">
          [Meta WABA Cloud API] Dispatched ledger_personal_remind -> Status: DELIVERED (200 OK)
        </span>
      </div>
      <div>
        <span style="color: var(--accent-gold); font-weight: 600;">🎁 Free Direct Meta API Key Setup Included</span>
      </div>
    </div>
  </div>

  <!-- Header -->
  <header class="editorial-header">
    <div class="container-wide header-flex">
      <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="brand-logo">
        <div class="brand-icon">AH</div>
        <span style="color: #fff;">HARNESS</span><span style="color: var(--accent-gold);">STUDIO</span>
      </a>
      <a href="#audit" class="btn-cta open-modal">Talk To The Founder</a>
    </div>
  </header>

  <!-- Editorial Main Container -->
  <main class="container-editorial">

    <!-- Hero Letter Header -->
    <section class="editorial-hero">
      <span class="kicker">// A PERSONAL LETTER TO REAL BUSINESS OPERATORS</span>
      <h1 class="main-headline">
        "Everyone Says AI Is The Future. But The Moment You Ask It To Do One Simple Thing For Your Business, <span>It Gives You Hallucination and AI Slop."</span>
      </h1>

      <div class="byline">
        <div class="author-img">AH</div>
        <div>
          <div style="color: #fff; font-weight: 700; font-size: 1.05rem;">By The Founder, Agent Harness Studio</div>
          <div style="font-size: 0.85rem;">Battle-Tested AI Practitioner | 1 Year First-Principles ICM Research</div>
        </div>
      </div>

      <p style="font-size: 1.25rem; color: #f1f5f9; font-weight: 500;">
        Look around the internet right now. It is completely full of AI slop and hype.
      </p>

      <p>
        You watch YouTubers in suits tell you <em>"AI will automate everything."</em> You buy their courses, pay for domain hosting, subscribe to different AI SaaS tools, and hire freelancers for ₹10,000.
      </p>

      <p>
        But the moment a customer sends a typo, asks about a pending invoice, or requests a ledger update — your bot crashes, sends a fake discount, angers your VIP buyer, or gets your primary WhatsApp business number <strong>permanently banned by Meta</strong>.
      </p>

      <div class="editorial-callout">
        <p>
          "I know this because I suffered through every single one of those traps myself. Here is the real story of how I stopped listening to fake gurus, learned that Context Is God, and engineered a deterministic 5-Layer Agent Harness that restored ₹72.42 Lakhs with zero Meta bans."
        </p>
      </div>

      <!-- Hero Visual Asset -->
      <div class="hero-image-wrap">
        <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/waba_dashboard.png' ); ?>" alt="Meta WABA Agent Harness Live Dashboard">
      </div>
    </section>

    <!-- Story Block 1: The YouTube Guru Trap -->
    <section class="story-block">
      <h2 class="story-heading">1. Trapped in the "YouTube AI Guru" Hype Cycle</h2>
      
      <p>
        When I first wanted to automate my business operations, I thought: <em>"Okay, I'll search the internet and do it myself for free."</em>
      </p>

      <p>
        I saw hundreds of YouTubers saying <em>"Do this, do that, build an AI automation agency in 24 hours."</em> Every single person had a different opinion. But after months of watching their videos and buying their courses, I realized one shocking thing:
      </p>

      <p style="font-size: 1.25rem; color: var(--accent-gold); font-weight: 700;">
        Nobody actually did it. None of them built a working system for a real business.
      </p>

      <p>
        They were not AI experts. <strong>They were YouTubers selling affiliate links.</strong>
      </p>

      <p>
        They sell domain hosting plans, promote affiliate SaaS subscriptions, sell $500 courses, and pitch generic automation templates. I fell right into their trap. I bought their courses, paid for website domain plans, subscribed to different AI SaaS tools, and tried putting AI into my business.
      </p>

      <p>
        <strong>And every single thing failed.</strong>
      </p>
    </section>

    <!-- Story Block 2: The WhatsApp & Meta API Nightmare -->
    <section class="story-block">
      <h2 class="story-heading">2. The WhatsApp API & Account Ban Nightmare</h2>

      <p>
        Then came the real test: I needed to automate my WhatsApp business to reach my clients and collect outstanding payment ledgers.
      </p>

      <p>
        Doing it myself was incredibly complex. Navigating Meta's developer portals, setting up system users, configuring webhooks, and getting permanent access tokens felt impossible.
      </p>

      <p>
        Then I saw third-party software platforms promising <em>"Easy WhatsApp API setup."</em> I signed up, connected my business number through their software...
      </p>

      <div class="disaster-box">
        <h4>🚨 THE DISASTER: META PERMANENTLY BANNED MY BUSINESS NUMBER</h4>
        <p style="color: #cbd5e1; margin-bottom: 0;">
          It turned out that software was not using Meta's Official API. They were using unapproved browser scrapers. Meta's automated security system detected the unauthorized connection and <strong>permanently banned my primary WhatsApp business number</strong>. Years of client history and trust vanished in one second.
        </p>
      </div>

      <p>
        Desperate for a fix, I paid ₹5,000 to ₹10,000 to freelancers selling n8n and Zapier workflows.
      </p>

      <p>
        That failed too. Their n8n scenarios broke every single time a client typed a typo, sent an emoji, or asked a question outside their rigid flowchart.
      </p>
    </section>

    <!-- Story Block 3: The Hallucination Nightmare -->
    <section class="story-block">
      <h2 class="story-heading">3. The 30-Day AI Hallucination Horror</h2>

      <p>
        I decided to build an AI agent myself. But because I didn't know how to manage AI context properly, the agent went completely wild:
      </p>

      <ul style="list-style: none; margin-bottom: 1.5rem; padding-left: 0;">
        <li style="margin-bottom: 0.75rem; color: #f87171;">❌ It ignored my business rules and hallucinated random invoice amounts.</li>
        <li style="margin-bottom: 0.75rem; color: #f87171;">❌ It sent wrong payment reminders to my top VIP buyers, making them furious.</li>
        <li style="margin-bottom: 0.75rem; color: #f87171;">❌ It spammed clients with duplicate messages and deleted/corrupted ledger data.</li>
      </ul>

      <p>
        For a full month, I was deeply frustrated with AI agents. 90% of what people were selling on the internet was pure junk and failure.
      </p>

      <!-- Live Interactive WhatsApp Simulator Widget -->
      <div class="simulator-box">
        <h4 style="font-size: 1.2rem; color: var(--accent-gold); margin-bottom: 0.5rem;">📱 Interactive Simulator: Flaky Bot vs Verified Harness</h4>
        <p style="font-size: 0.88rem; color: var(--text-secondary); margin-bottom: 1.25rem;">
          Click the scenarios below to see how a generic AI bot fails vs how our verified WABA Harness executes:
        </p>

        <div class="simulator-grid">
          <div>
            <button class="sim-btn active" data-scenario="flaky">🔴 Scenario A: Flaky AI Bot (Hallucination)</button>
            <button class="sim-btn" data-scenario="waba_harness">🟢 Scenario B: Verified WABA Harness (0% Error)</button>
            <button class="sim-btn" data-scenario="disputed">⚡ Scenario C: Disputed Client (Smart HITL Pause)</button>
          </div>
          <div class="chat-screen" id="chat-simulator-display">
            <div class="chat-bubble chat-in">Hi, I want to check my pending invoice balance for Acme Traders.</div>
            <div class="chat-bubble chat-out" style="background: #7f1d1d;">[Generic AI Bot] Sure! Your total owed is ₹4,500.00. We can also give you a special 40% discount if you pay today! Click here: http://fake-link.com</div>
            <div class="chat-bubble chat-in" style="color: #f87171;">⚠️ ERROR: Customer replied "I already paid yesterday! Why are you asking again and offering false discounts?" -> Customer angry, Meta Quality Rating tanked.</div>
          </div>
        </div>
      </div>
    </section>

    <!-- Story Block 4: The ICM Breakthrough -->
    <section class="story-block">
      <h2 class="story-heading">4. The Breakthrough: "Context Is God" & ICM Protocol</h2>

      <p>
        I stopped listening to YouTubers and studied <strong>Interpretable Context Methodology (ICM)</strong> from first principles.
      </p>

      <p>
        I learned the single most important rule in artificial intelligence:
      </p>

      <div class="editorial-callout" style="border-color: var(--accent-emerald); background: var(--accent-emerald-soft);">
        <p style="color: #ffffff; font-weight: 700;">
          "CONTEXT IS GOD. If you do not tightly govern the AI's context window with structured, sovereign files before execution, the model WILL hallucinate."
        </p>
      </div>

      <!-- Harness Architecture Image -->
      <div class="hero-image-wrap">
        <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/harness_architecture.png' ); ?>" alt="5-Layer Agent Harness Architecture Diagram">
      </div>

      <p>
        I built an <strong>Agent Harness</strong> based on the 5-Layer Context Hierarchy:
      </p>

      <ol style="margin-bottom: 1.5rem; padding-left: 1.5rem; color: #cbd5e1;">
        <li style="margin-bottom: 0.5rem;"><strong style="color: var(--accent-gold);">Layer 1 (`AGENTS.md`)</strong>: Universal guardrails & immutable trust boundaries.</li>
        <li style="margin-bottom: 0.5rem;"><strong style="color: var(--accent-gold);">Layer 2 (`CONTEXT.md`)</strong>: Master pipeline routing across stages.</li>
        <li style="margin-bottom: 0.5rem;"><strong style="color: var(--accent-gold);">Layer 3 (`contract.schema.json`)</strong>: Hard mathematical gates (0% numeric error tolerance).</li>
        <li style="margin-bottom: 0.5rem;"><strong style="color: var(--accent-gold);">Layer 4 (`SOUL.md`)</strong>: Business rules, policies, and Smart HITL Pause blacklists.</li>
        <li style="margin-bottom: 0.5rem;"><strong style="color: var(--accent-gold);">Layer 5 (Telemetry)</strong>: Anchoring all actions to empirical database events.</li>
      </ol>

      <p>
        The AI was physically blocked from guessing numbers or acting on unvalidated text. <strong>And suddenly, the system started giving 100% accurate results.</strong>
      </p>
    </section>

    <!-- Story Block 5: The FREE Meta API Key Gift -->
    <section class="story-block">
      <div class="gift-box">
        <h3>🎁 Why We Give You A FREE Direct Meta API Key</h3>
        <p style="color: #e2e8f0; margin-bottom: 1rem;">
          During my journey, I discovered that Meta provides the Official WABA Cloud API key <strong>100% FREE directly from Meta</strong>.
        </p>
        <p style="color: #e2e8f0; margin-bottom: 0;">
          Agencies and middleman platforms charge you thousands of rupees per month for API access. <strong>We don't charge you a single rupee for your API key.</strong> We set up your direct Official Meta Cloud API key for free — saving you from vendor taxes while giving you 0% account ban risk.
        </p>
      </div>
    </section>

    <!-- Interactive DSO & ROI Calculator Widget -->
    <section class="story-block">
      <h2 class="story-heading">5. Calculate Your Unlocked Cash Flow</h2>
      <p>
        See how much working capital your business unlocks when manual ledger follow-ups are automated with an official WABA Agent Harness:
      </p>

      <div class="calc-box">
        <div class="calc-slider-wrap">
          <label>
            <span>Monthly Outstanding Receivables (Lakhs):</span>
            <span id="calc-amount-label" style="color: var(--accent-gold); font-weight: 700;">₹50.0 Lakhs</span>
          </label>
          <input type="range" id="calc-amount-slider" class="calc-slider" min="5" max="200" step="5" value="50">
        </div>

        <div class="calc-slider-wrap">
          <label>
            <span>Current Average Payment Delay (Days):</span>
            <span id="calc-dso-label" style="color: var(--accent-gold); font-weight: 700;">45 Days</span>
          </label>
          <input type="range" id="calc-dso-slider" class="calc-slider" min="15" max="90" step="5" value="45">
        </div>

        <div class="calc-result-grid">
          <div>
            <div style="font-size: 0.85rem; color: var(--text-secondary); margin-bottom: 0.25rem;">Working Capital Unlocked</div>
            <div class="calc-result-val" id="calc-unlocked-cash">₹20.00 Lakhs</div>
          </div>
          <div>
            <div style="font-size: 0.85rem; color: var(--text-secondary); margin-bottom: 0.25rem;">Collection Velocity Improvement</div>
            <div class="calc-result-val" id="calc-dso-reduced" style="color: var(--accent-gold);">45d → 27d (18 days faster)</div>
          </div>
        </div>
      </div>
    </section>

    <!-- Forensic Case Study -->
    <section class="story-block">
      <h2 class="story-heading">6. Real Forensic Proof: Jai Maa Bhagwati Traders (JMBT)</h2>

      <p>
        I didn't test this on a fake demo. I deployed it on a real high-volume wholesale business with over ₹70 Lakhs locked in delayed customer ledgers across 1,181 buyers.
      </p>

      <div class="case-study-narrative">
        <h3 style="font-size: 1.75rem; color: var(--accent-gold); margin-bottom: 1rem;">The ₹72.42 Lakhs Forensic Audit</h3>
        <p>
          Manual staff calling was taking weeks and ruining buyer relationships. Unofficial scrapers had almost gotten them banned.
        </p>
        <p>
          We deployed our custom 5-Layer Agent Harness using their direct FREE Meta API key. The system ingested PDF statements, normalized phone numbers, segmented buyers into 6 Granular Pillars, and automatically paused 92 disputed clients for human reconciliation.
        </p>

        <div class="stats-grid">
          <div class="stat-item">
            <div class="stat-val">₹72.42L</div>
            <div class="stat-lbl">Dues Tracked & Restored</div>
          </div>
          <div class="stat-item">
            <div class="stat-val">1,181</div>
            <div class="stat-lbl">Active Clients Segmented</div>
          </div>
          <div class="stat-item">
            <div class="stat-val">92 Clients</div>
            <div class="stat-lbl">Safely Paused (HITL)</div>
          </div>
          <div class="stat-item">
            <div class="stat-val">0 Bans</div>
            <div class="stat-lbl">100% Direct Meta API</div>
          </div>
        </div>
      </div>
    </section>

    <!-- Interactive Rule Inspector: Context is God -->
    <section class="story-block">
      <h2 class="story-heading">7. Inspect The Transparent Rule Files</h2>
      <p>
        We don't sell black-box SaaS tools. We build custom software inside your company. All rules live in human-readable Markdown files that you can inspect and edit anytime:
      </p>

      <div class="file-inspector">
        <div class="inspector-nav">
          <button class="inspector-tab active" data-file="AGENTS.md">AGENTS.md (Guardrails)</button>
          <button class="inspector-tab" data-file="SOUL.md">SOUL.md (Business Rules)</button>
          <button class="inspector-tab" data-file="contract.schema.json">contract.schema.json (0% Error Gate)</button>
        </div>
        <pre id="inspector-code-display" class="inspector-code">/* ==========================================================================
   AGENTS.md — Universal Identity & Guardrail Layer (Layer 1)
   ========================================================================== */

# IMMUTABLE SOVEREIGN CONTRACT
- Role: Deterministic Revenue & Ledger Automation Agent
- Engine: 100% Meta Official WhatsApp Business API (Direct WABA Cloud Key)
- Rule 1: NEVER guess or hallucinate currency figures or ledger balances.
- Rule 2: All automation triggers must anchor to verified database events.
- Rule 3: Disputed client accounts trigger immediate Smart HITL Pause.

## TRUST & DATA BOUNDARIES
- Allowed: Read ledger balances, dispatch Meta-approved utility templates.
- Forbidden: Cannot issue unauthorized discounts or modify core accounts without owner key.</pre>
      </div>
    </section>

    <!-- FAQ -->
    <section class="story-block">
      <h2 class="story-heading">Frequently Asked Questions</h2>
      
      <div class="faq-list">
        <div class="faq-card">
          <button class="faq-q">
            <span>Why do you give us a FREE Direct Meta API key instead of charging for API access?</span>
            <span>+</span>
          </button>
          <div class="faq-a">
            Because Meta provides direct Cloud API access for free, and third-party middleman SaaS tools mark up fees unnecessarily while introducing ban risk. We set up your direct Meta API key so you pay zero vendor taxes and get 100% official compliance.
          </div>
        </div>

        <div class="faq-card">
          <button class="faq-q">
            <span>How do you guarantee the AI won't hallucinate or send wrong amounts?</span>
            <span>+</span>
          </button>
          <div class="faq-a">
            We use strict `contract.schema.json` validation gates. The AI is not allowed to generate financial numbers freely; it must pass hard mathematical and schema checks against your database before any message is sent.
          </div>
        </div>

        <div class="faq-card">
          <button class="faq-q">
            <span>Why build software inside our company instead of selling a monthly SaaS app?</span>
            <span>+</span>
          </button>
          <div class="faq-a">
            Because every real business has unique rules, edge cases, and client nuances. Generic SaaS tools force you into rigid templates that break. We build custom, file-based software inside your environment so you retain 100% control, ownership, and data privacy.
          </div>
        </div>

        <div class="faq-card">
          <button class="faq-q">
            <span>What happens if a client disputes an invoice or asks for more time?</span>
            <span>+</span>
          </button>
          <div class="faq-a">
            Our Smart Human-in-the-Loop (HITL) pause engine automatically flags disputed accounts or payment promises within 30 days and removes them from automated dunning queues for manual owner review.
          </div>
        </div>
      </div>
    </section>

    <!-- Closing Call To Action -->
    <section id="audit" class="story-block" style="text-align: center; border-bottom: none; padding-bottom: 5rem;">
      <span class="kicker">// LIMITED MONTHLY INTAKE</span>
      <h2 style="font-size: 2.75rem; margin-bottom: 1.25rem;">We Only Partner With 2 Companies Per Month</h2>
      <p style="color: var(--text-secondary); max-width: 640px; margin: 0 auto 2.25rem;">
        Because every build is custom software engineered specifically for your business operations, we restrict our intake to guarantee 100% zero-error execution.
      </p>
      <button class="btn-cta open-modal" style="font-size: 1.15rem; padding: 1.1rem 2.75rem;">Talk To The Founder — Book 15-Min Problem Audit</button>
    </section>

  </main>

  <!-- Footer -->
  <footer class="footer">
    <div class="container-editorial">
      <p>© <?php echo date('Y'); ?> Agent Harness Studio. Engineered with Interpretable Context Methodology (ICM) & Direct Meta WABA API Keys.</p>
    </div>
  </footer>

  <!-- Booking Modal -->
  <div id="founder-modal" class="modal-overlay">
    <div class="modal-content">
      <button class="modal-close">&times;</button>
      <h3 style="font-size: 1.6rem; color: #fff; margin-bottom: 0.5rem;">Schedule Your 15-Min Problem Audit</h3>
      <p style="font-size: 0.9rem; color: var(--text-secondary); margin-bottom: 1.5rem;">
        Tell us about your primary business bottleneck. You will speak directly with the founder — no pushy sales reps or generic pitches.
      </p>

      <form id="founder-audit-form">
        <div class="form-group">
          <label class="form-label">Your Name</label>
          <input type="text" class="form-input" placeholder="e.g. Rajesh Kumar" required>
        </div>
        <div class="form-group">
          <label class="form-label">Company Name & Industry</label>
          <input type="text" class="form-input" placeholder="e.g. Acme Wholesale (B2B Distribution)" required>
        </div>
        <div class="form-group">
          <label class="form-label">WhatsApp Number / Email</label>
          <input type="text" class="form-input" placeholder="+91 98765 43210 / name@company.com" required>
        </div>
        <div class="form-group">
          <label class="form-label">Primary Business Challenge</label>
          <select class="form-select" required>
            <option value="">Select your main bottleneck...</option>
            <option value="collections">High DSO / Lakhs stuck in uncollected ledgers</option>
            <option value="banned">Got WhatsApp account banned by un-official tools</option>
            <option value="hallucinations">AI bot hallucinations & wrong message sending</option>
            <option value="custom">Need custom Tally/ERP & file-based automation</option>
          </select>
        </div>
        <button type="submit" class="btn-cta" style="width: 100%; margin-top: 1rem;">Book Audit With Founder</button>
      </form>
    </div>
  </div>

  <?php wp_footer(); ?>
</body>
</html>
